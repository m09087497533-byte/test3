"""Sparse accents from the supplied words, independent of the effects rotation."""
import math
from types import SimpleNamespace
from .phrases import emphasis_events
from .appearances import APPEARANCE_LABELS, accent_id, apply_appearance, clean_overrides

STYLE_LABELS={'red_ink':'Красные цифры с обводкой','neon':'Светящиеся цифры',
              'chromatic':'Дата с цветной тенью','editorial':'Текст с перспективой',
              'italic':'Курсивная фраза','marquee':'Бегущие строки на сетке',
              'caption':'Короткая подпись','classic':'Появление текста'}


def plan_accents(segments,duration=None,major_rate=2,fps=25,overrides=None):
    if not segments:return []
    if duration is None:duration=max(float(s['end']) for s in segments)
    cues=[SimpleNamespace(text=s['text'],start=float(s['start']),end=float(s['end'])) for s in segments]
    events=[];number=0;overrides=clean_overrides(overrides)
    for original in emphasis_events(cues,major_rate=max(0,min(4,int(major_rate)))):
        event={k:v for k,v in original.items() if k!='priority'}
        start=max(0,round(event['start']*fps));end=min(math.ceil(duration*fps),round(event['end']*fps))
        if end<=start:continue
        event.update(start=start/fps,end=end/fps,span=(end-start)/fps,elapsed=0)
        event.setdefault('tier','major');event.setdefault('treatment','classic')
        if event['tier']=='caption':
            event.update(layout='label',treatment='classic',effect='typewriter',duration=.45)
        elif event['layout']=='grid':event['effect']='marquee'
        elif event['layout']=='number':
            event['treatment']=('red_ink','neon','chromatic')[number%3];number+=1
        elif event['effect']=='perspective':event['treatment']='editorial'
        event['style_label']=STYLE_LABELS['caption' if event['tier']=='caption' else 'marquee' if event['effect']=='marquee' else event['treatment']]
        if event['style_label']==STYLE_LABELS['classic']:
            event['style_label']=APPEARANCE_LABELS.get(event['effect'],event['style_label'])
        event['id']=accent_id(event,fps)
        choice=overrides.get(event['id'],{}).get('appearance','auto')
        events.append(apply_appearance(event,choice))
    for i,event in enumerate(events):
        if event['effect']!='marquee':continue
        # More reading time, without moving narration, the next accent or cuts.
        hold=min(8.,max(4.,len(event['text'].split())/2.6+.8))
        limit=min(duration,events[i+1]['start']-.12 if i+1<len(events) else duration)
        end=min(limit,max(event['end'],event['start']+hold))
        event['end']=max(event['start']+1/fps,math.floor((end+1e-8)*fps)/fps)
        event['span']=event['end']-event['start']
    return events
