"""Transparent animated titles, independently composited over the scene."""
import math
from PIL import Image, ImageDraw, ImageFilter

ADVANCED = {'scroll', 'perspective', 'reveal', 'stamp', 'typewriter'}


def perspective_coefficients(destination, source):
    rows = []
    for (x,y),(u,v) in zip(destination,source):
        rows.extend([[x,y,1,0,0,0,-u*x,-u*y,u], [0,0,0,x,y,1,-v*x,-v*y,v]])
    for col in range(8):
        pivot = max(range(col,8),key=lambda row:abs(rows[row][col]))
        rows[col],rows[pivot] = rows[pivot],rows[col]
        factor = rows[col][col]
        if abs(factor)<1e-10:
            raise ValueError('Degenerate title perspective')
        rows[col] = [v/factor for v in rows[col]]
        for row in range(8):
            if row!=col:
                factor = rows[row][col]
                rows[row] = [a-factor*b for a,b in zip(rows[row],rows[col])]
    return tuple(row[-1] for row in rows)


def title_frame(layer, scene, effect, elapsed):
    w,h=layer.size
    duration=max(1,round(scene.title_duration*25))/25
    p=max(0,min(1,elapsed/duration))
    ease=1-(1-p)**3
    box=layer.getbbox()
    if not box:
        return layer.copy()
    x0,y0,x1,y1=box
    result=Image.new('RGBA',layer.size)
    if effect=='perspective' and p<1:
        # A foreshortened plane rises from below and straightens to the final title.
        center=(x0+x1)/2
        top_width=(x1-x0)*(0.68+0.32*ease)
        bottom_width=(x1-x0)*(1.25-.25*ease)
        top=y0+(1-ease)*h*.24
        bottom=top+(y1-y0)*(.20+.80*ease)
        dst=[(center-top_width/2,top),(center+top_width/2,top),
             (center+bottom_width/2,bottom),(center-bottom_width/2,bottom)]
        src=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
        result=layer.transform(layer.size,Image.Transform.PERSPECTIVE,perspective_coefficients(dst,src),Image.Resampling.BICUBIC)
    elif effect=='stamp':
        ratio=1+.24*(1-ease)
        scaled=layer.resize((round(w*ratio),round(h*ratio)),Image.Resampling.BICUBIC)
        result.paste(scaled,((w-scaled.width)//2,(h-scaled.height)//2))
    elif effect in ('reveal','typewriter'):
        # Clip left to right, preserving glyph positions and line wrapping.
        fraction=ease if effect=='reveal' else math.floor(p*max(1,len(scene.title)))/max(1,len(scene.title))
        right=round(x0+(x1-x0)*fraction)
        if right>x0: result.paste(layer.crop((0,0,right,h)),(0,0))
    elif effect in ('reveal_right','split'):
        if effect=='reveal_right':
            left=round(x1-(x1-x0)*ease);right=x1
        else:
            center=(x0+x1)/2;half=(x1-x0)*ease/2
            left=round(center-half);right=round(center+half)
        if right>left:result.paste(layer.crop((left,0,right,h)),(left,0))
    elif effect in ('text_zoom_in','text_zoom_out','pop','stretch','tilt'):
        back=1+2.70158*(p-1)**3+1.70158*(p-1)**2
        ratio=(.7+.3*ease if effect=='text_zoom_in' else
               1.4-.4*ease if effect=='text_zoom_out' else
               max(.01,back) if effect=='pop' else
               .85+.15*ease if effect=='tilt' else 1)
        vertical=max(.01,ease) if effect=='stretch' else ratio
        scaled=layer.resize((max(1,round(w*ratio)),max(1,round(h*vertical))),Image.Resampling.BICUBIC)
        if effect=='tilt':scaled=scaled.rotate((1-ease)*-14,resample=Image.Resampling.BICUBIC)
        result.paste(scaled,((w-scaled.width)//2,(h-scaled.height)//2))
    elif effect in ('from_left','from_right','from_top','from_bottom','bounce'):
        back=1+2.70158*(p-1)**3+1.70158*(p-1)**2
        dx=round((1-ease)*w*(-1 if effect=='from_left' else 1)) if effect in ('from_left','from_right') else 0
        dy=round((1-ease)*h*(-1 if effect=='from_top' else 1)) if effect in ('from_top','from_bottom') else round((1-back)*h*.35) if effect=='bounce' else 0
        result.paste(layer,(dx,dy))
    elif effect=='focus':
        result=layer.filter(ImageFilter.GaussianBlur((1-ease)*w/85))
    else:
        dx=round(w*(1-ease)) if effect=='scroll' else -round(w*(1-ease)) if effect=='slide' else 0
        dy=round(h*.16*(1-ease)) if effect=='rise' else 0
        result.paste(layer,(dx,dy))
    if effect not in ('static','reveal') and p<1:
        if effect in ('scroll','perspective'):
            result=result.filter(ImageFilter.GaussianBlur((1-ease)*w/500))
        alpha=ease if effect in ('soft_fade','focus') else min(1,p*5)
        result.putalpha(result.getchannel('A').point(lambda v:round(v*alpha)))
    # Draw one continuous, slightly irregular stroke around the settled title.
    if scene.title_decoration!='none':
        q=max(0,min(1,(elapsed-duration*.65)/.65))
        if q:
            d=ImageDraw.Draw(result)
            if scene.title_decoration=='underline':
                d.line((x0,y1+h*.018,x0+(x1-x0)*q,y1+h*.018),fill='#ef9e64',width=max(2,round(w/400)))
            else:
                cx,cy=(x0+x1)/2,(y0+y1)/2
                rx,ry=(x1-x0)/2+w*.018,(y1-y0)/2+h*.035
                points=[]
                for i in range(max(2,round(180*q))):
                    angle=-.35+2*math.pi*1.06*i/179
                    points.append((cx+rx*math.cos(angle),cy+ry*math.sin(angle)+h*.005*math.sin(angle*3)))
                d.line(points,fill='#ef9e64',width=max(2,round(w/550)),joint='curve')
    return result
